To change the program settings, i.e. network configuration, modify these files:  
- GreedyGameService.exe.config in Service folder
- GreedyGameClient.exe.config in Client folder

To start the program:  
- Run GreedyGameService.exe in Service folder as Administrator to start the service
- Run GreedyGameClient.exe in Client folder to start the client

